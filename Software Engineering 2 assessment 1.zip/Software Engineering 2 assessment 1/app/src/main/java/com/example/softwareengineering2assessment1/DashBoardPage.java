package com.example.softwareengineering2assessment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class DashBoardPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board_page);
    }
    public void performDashBoardSignOut(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void performDashBoardViewHistoryBooking(View view){
        Intent intent = new Intent( this, ViewHistoryBooking.class);
        startActivity(intent);
    }

    public void performDashBoardPageBttnNewBooking(View view){
        Intent intent = new Intent( this, NewBooking.class);
        startActivity(intent);
    }

}