package com.example.softwareengineering2assessment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
    }

    public void backToMain(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void performLoginPageBttnOK(View view){
        EditText tbUsername = findViewById(R.id.tbUsername);    // get the text box object
        String username = tbUsername.getText().toString();      // get the text inside the text box

        EditText tbPassword = findViewById(R.id.tbPassword);
        String password = tbPassword.getText().toString();

        if (username.equals("JackyHo") && password.equals("FightCOVID-19"))
        {
            // user name and password are correct, go to Dash Board page
            Intent intent = new Intent(this, DashBoardPage.class);
            startActivity(intent);
        }
        else {
            // either user name or password is incorrect, show the error message
            Toast toast = Toast.makeText(getApplicationContext(), "Invalid user name or password", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

}