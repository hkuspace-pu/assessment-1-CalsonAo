package com.example.softwareengineering2assessment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class NewBooking extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_booking);
    }
    public void performNewBookingBook(View view){
        Intent intent = new Intent( this, ViewHistoryBooking.class);
        startActivity(intent);
    }
    public void performNewBookingBttnCanceltoDashBoard(View view){
        Intent intent = new Intent( this, DashBoardPage.class);
        startActivity(intent);
    }
    public void performNewBookingPageBttnExplanationToExplan(View view){
        Intent intent = new Intent( this, AccommodationExplanation.class);
        startActivity(intent);
    }


}